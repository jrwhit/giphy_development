import 'package:flutter/material.dart';
import 'package:giphy_development/ui/tela_principal.dart';

void main() => runApp(MaterialApp(
  home: MyHomePage(),
));